import pygame
import pygame.freetype
from pygame.sprite import Sprite
from enum import Enum
from pygame.sprite import RenderUpdates
from games.pong import pong_game

B = (0, 0, 0)
W = (255, 255, 255)

# Initial value of paddles
with open("games_data/paddles_length.txt", mode="r") as data:
    length = int(data.read())

with open("games_data/ball_speed.txt", mode="r") as data:
    speed = float(data.read())

# Colors for the dropdown list
COLOR_DICT = {
    "color": [
        "Black",
        "White",
        "Red",
        "Lime",
        "Blue",
        "Yellow",
        "Cyan",
        "Magenta",
        "Silver",
        "Gray",
        "Green",
        "Purple",
        "Navy"
    ],
    "rgbs": [
        (0, 0, 0),
        (255, 255, 255),
        (255, 0, 0),
        (0, 255, 0),
        (0, 0, 255),
        (255, 255, 0),
        (0, 255, 255),
        (255, 0, 255),
        (192, 192, 192),
        (128, 128, 128),
        (0, 128, 0),
        (128, 0, 128),
        (0, 0, 128)
    ]
}

# Colors for the active and inactive buttons of the dropdown list
COLOR_INACTIVE = (0, 255, 255)
COLOR_ACTIVE = (0, 0, 255)
COLOR_LIST_INACTIVE = (255, 0, 0)
COLOR_LIST_ACTIVE = (255, 255, 0)


# Creating a surface with text
def create_surf_with_text(text, font_size, text_rgb, bg_rgb):
    font = pygame.freetype.SysFont("Verdana", font_size, bold=True)
    surface, _ = font.render(text=text, fgcolor=text_rgb, bgcolor=bg_rgb)
    return surface.convert_alpha()


# Creating a dropdown list
class DropDown():
    def __init__(self, color_menu, color_opt, x, y, w, h, font, main, options):
        self.color_menu = color_menu
        self.color_option = color_opt
        self.rect = pygame.Rect(x, y, w, h)
        self.font = font
        self.main = main
        self.options = options
        self.draw_menu = False
        self.menu_active = False
        self.active_option = -1

    # Drawing the dropdown list
    def draw(self, surf):
        pygame.draw.rect(surf, self.color_menu[self.menu_active], self.rect, 0)
        msg = self.font.render(self.main, 1, B)
        surf.blit(msg, msg.get_rect(center=self.rect.center))

        if self.draw_menu:
            for i, text in enumerate(self.options):
                rect = self.rect.copy()
                rect.y += (i + 1) * self.rect.height
                if i == self.active_option:
                    pygame.draw.rect(surf, self.color_option[1], rect, 0)
                else:
                    pygame.draw.rect(surf, self.color_option[0], rect, 0)
                msg = self.font.render(text, 1, B)
                surf.blit(msg, msg.get_rect(center=rect.center))

    # Updating the dropdown list
    def update(self, event_list):
        mouse_pos = pygame.mouse.get_pos()
        self.menu_active = self.rect.collidepoint(mouse_pos)

        self.active_option = -1
        for i in range(len(self.options)):
            rect = self.rect.copy()
            rect.y += (i+1) * self.rect.height
            if rect.collidepoint(mouse_pos):
                self.active_option = i
                break

        if not self.menu_active and self.active_option == -1:
            self.draw_menu = False

        for event in event_list:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.menu_active:
                    self.draw_menu = not self.draw_menu
                elif self.draw_menu and self.active_option >= 0:
                    self.draw_menu = False
                    return self.active_option
        return -1


# Creatin a text
class TitleText(Sprite):
    def __init__(self, center, text, font_size, bg_rgb, txt_rgb):
        super().__init__()
        title_image = create_surf_with_text(text, font_size, txt_rgb, bg_rgb)
        self.image = title_image
        self.rect = title_image.get_rect(center=center)

    def draw(self, surface):
        surface.blit(self.image, self.rect)


# Creating an UI element like a button
class UIElement(Sprite):
    def __init__(self, center, text, font_size, bg_rgb, txt_rgb, action=None):

        super().__init__()
        self.mouse_over = False
        default_image = create_surf_with_text(text, font_size, txt_rgb, bg_rgb)
        high_ig = create_surf_with_text(text, font_size * 1.2, txt_rgb, bg_rgb)
        self.images = [default_image, high_ig]
        df_img = default_image.get_rect(center=center)
        hg_img = high_ig.get_rect(center=center)
        self.rects = [df_img, hg_img]
        self.action = action

    @property
    def image(self):
        return self.images[1] if self.mouse_over else self.images[0]

    @property
    def rect(self):
        return self.rects[1] if self.mouse_over else self.rects[0]

    def update(self, mouse_pos, mouse_up):
        if self.rect.collidepoint(mouse_pos):
            self.mouse_over = True
            if mouse_up:
                return self.action
        else:
            self.mouse_over = False

    def draw(self, surface):
        surface.blit(self.image, self.rect)


# Defining different game states
class GameState(Enum):
    QUIT = -1
    TITLE = 0
    NEWGAME = 1
    INCREASE = 2
    OPTIONS = 3
    CREDITS = 4
    CUSTOMIZE = 5
    HOME = 6
    AWAY = 7
    MODE_CHOSE = 8
    HORIZONTAL = 9
    VERTICAL = 10
    DECREASE = 11
    INC_DEC = 12


# Main commands
def main():
    pygame.init()

    screen = pygame.display.set_mode((900, 700))
    game_state = GameState.TITLE
    while True:
        if game_state == GameState.TITLE:
            game_state = title_screen(screen)

        if game_state == GameState.NEWGAME:
            game_state = game_mode(screen)

        if game_state == GameState.HORIZONTAL:
            game_state = play_horizontal()

        if game_state == GameState.VERTICAL:
            game_state = play_vertical()

        if game_state == GameState.OPTIONS:
            game_state = options_menu(screen)

        if game_state == GameState.CREDITS:
            game_state = credits(screen)

        if game_state == GameState.CUSTOMIZE:
            game_state = customize_colors(screen)

        if game_state == GameState.HOME:
            game_state = home(screen)

        if game_state == GameState.AWAY:
            game_state = away(screen)

        if game_state == GameState.INCREASE:
            global length
            length += 1
            game_state = paddle_length(screen)

        if game_state == GameState.DECREASE:
            length -= 1
            game_state = paddle_length(screen)

        if game_state == GameState.INC_DEC:
            game_state = paddle_length(screen)

        if game_state == GameState.QUIT:
            pygame.quit()
            return


# Creating the title screen
def title_screen(screen):
    text = TitleText((450, 150), "PONG", 150, B, W)
    strt = UIElement((450, 350), "NEW GAME", 40, B, W, GameState.NEWGAME)
    opt = UIElement((450, 400), "OPTIONS", 40, B, W, GameState.OPTIONS)
    crd = UIElement((450, 450), "CREDITS", 40, B, W, GameState.CREDITS)
    quit = UIElement((450, 550), "EXIT", 40, B, W, GameState.QUIT)

    buttons = RenderUpdates(strt, opt, crd, quit)
    texts = RenderUpdates(text)

    return game_loop(screen, buttons, texts)


# Creating the game mode menu
def game_mode(screen):
    txt = "Return to main menu"
    r_b = UIElement((150, 650), txt, 20, B, W, GameState.TITLE)
    hrz = UIElement((250, 350), "Horizontal", 40, B, W, GameState.HORIZONTAL)
    ver = UIElement((650, 350), "Vertical", 40, B, W, GameState.VERTICAL)
    msg = TitleText((450, 200), "Choose Game Mode", 60, B, W)

    buttons = RenderUpdates(r_b, hrz, ver)
    texts = RenderUpdates(msg)

    return game_loop(screen, buttons, texts)


# Selecting the game modes
def play_horizontal():
    pong_game.response = 'horizontal'
    pygame.quit()
    pong_game.mode_choose()
    exit()


def play_vertical():
    pong_game.response = 'vertical'
    pygame.quit()
    pong_game.mode_choose()
    exit()


# Customizing menu
def customize_colors(screen):
    txt = "Return to options menu"
    r_b = UIElement((170, 650), txt, 20, B, W, GameState.OPTIONS)
    home = UIElement((250, 350), "Home color", 40, B, W, GameState.HOME)
    away = UIElement((650, 350), "Away color", 40, B, W, GameState.AWAY)

    buttons = RenderUpdates(r_b, home, away)
    texts = RenderUpdates()

    return game_loop(screen, buttons, texts)


# Customizing the away color
def away(screen):
    txt = "Return to customization menu"
    r_b = UIElement((210, 650), txt, 20, B, W, GameState.CUSTOMIZE)
    clr = [COLOR_INACTIVE, COLOR_ACTIVE]
    clr_list = [COLOR_LIST_INACTIVE, COLOR_LIST_ACTIVE]
    fnt = pygame.font.SysFont(None, 30)
    txt = "Select Color"
    clr_d = COLOR_DICT["color"]
    option_d_p = DropDown(clr, clr_list, 350, 0, 200, 45, fnt, txt, clr_d)
    buttons = RenderUpdates(r_b)
    texts = RenderUpdates()

    while True:
        mouse_up = False
        event_list = pygame.event.get()
        for event in event_list:
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                mouse_up = True

        screen.fill(B)

        for button in buttons:
            ui_act = button.update(pygame.mouse.get_pos(), mouse_up)
            if ui_act is not None:
                return ui_act

        selected_option = option_d_p.update(event_list)
        if selected_option >= 0:
            with open("games_data/paddle2_color.txt", mode="w") as data:
                data.write(str(COLOR_DICT["color"][selected_option].lower()))
            option_d_p.main = option_d_p.options[selected_option]

        screen.fill(B)
        texts.draw(screen)
        buttons.draw(screen)
        option_d_p.draw(screen)
        pygame.display.flip()


# Customizing the home color
def home(screen):
    txt = "Return to customization menu"
    r_b = UIElement((210, 650), txt, 20, B, W, GameState.CUSTOMIZE)
    clr = [COLOR_INACTIVE, COLOR_ACTIVE]
    clr_list = [COLOR_LIST_INACTIVE, COLOR_LIST_ACTIVE]
    fnt = pygame.font.SysFont(None, 30)
    txt = "Select Color"
    clr_d = COLOR_DICT["color"]
    option_d_p = DropDown(clr, clr_list, 350, 0, 200, 45, fnt, txt, clr_d)
    buttons = RenderUpdates(r_b)
    texts = RenderUpdates()

    while True:
        mouse_up = False
        event_list = pygame.event.get()
        for event in event_list:
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                mouse_up = True

        screen.fill(B)

        for button in buttons:
            ui_act = button.update(pygame.mouse.get_pos(), mouse_up)
            if ui_act is not None:
                return ui_act

        selected_option = option_d_p.update(event_list)
        if selected_option >= 0:
            with open("games_data/paddle1_color.txt", mode="w") as data:
                data.write(str(COLOR_DICT["color"][selected_option].lower()))
            option_d_p.main = option_d_p.options[selected_option]

        screen.fill(B)
        texts.draw(screen)
        buttons.draw(screen)
        option_d_p.draw(screen)
        pygame.display.flip()


# Customzing the length of the paddles
def paddle_length(screen):
    global length
    txt = "Return to options menu"
    r_b = UIElement((170, 650), txt, 20, B, W, GameState.OPTIONS)
    curr_l = TitleText((450, 250), f"Current lenght: {length} px", 50, B, W)
    increase = UIElement((450, 350), "Increase", 40, B, W, GameState.INCREASE)
    decrease = UIElement((450, 450), "Decrease", 40, B, W, GameState.DECREASE)
    with open("games_data/paddles_length.txt", mode="w") as data:
        data.write(str(length))

    buttons = RenderUpdates(r_b, increase, decrease)
    texts = RenderUpdates(curr_l)

    return game_loop(screen, buttons, texts)


# Creating the options menu
def options_menu(screen):
    txt = "Return to main menu"
    r_b = UIElement((150, 650), txt, 20, B, W, GameState.TITLE)
    txt_2 = "Customize the colors"
    c_bt = UIElement((450, 300), txt_2, 40, B, W, GameState.CUSTOMIZE)
    txt_3 = "Customize paddle length"
    p_bt = UIElement((450, 400), txt_3, 40, B, W, GameState.INC_DEC)
    buttons = RenderUpdates(r_b, c_bt, p_bt)
    texts = RenderUpdates()
    return game_loop(screen, buttons, texts)


# Creating the credits menu
def credits(screen):
    txt = "Return to main menu"
    r_b = UIElement((150, 650), txt, 20, B, W, GameState.TITLE)
    msg = TitleText((450, 350), "PONG 2021", 70, B, W)
    buttons = RenderUpdates(r_b)
    texts = RenderUpdates(msg)

    return game_loop(screen, buttons, texts)


# Creating the game loop
def game_loop(screen, buttons, texts):
    while True:
        mouse_up = False
        event_list = pygame.event.get()
        for event in event_list:
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                mouse_up = True

        screen.fill(B)

        for button in buttons:
            ui_act = button.update(pygame.mouse.get_pos(), mouse_up)
            if ui_act is not None:
                return ui_act

        texts.draw(screen)
        buttons.draw(screen)
        pygame.display.flip()


if __name__ == "__main__":
    main()
