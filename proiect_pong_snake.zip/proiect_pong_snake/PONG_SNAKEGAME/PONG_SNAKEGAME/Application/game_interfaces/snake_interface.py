import pygame
import pygame.freetype
from pygame.sprite import Sprite
from enum import Enum
from pygame.sprite import RenderUpdates
from games.snake import snake_game

B = (0, 0, 0)
W = (255, 255, 255)

# Colors for the dropdown list
COLOR_DICT = {
    "color": [
        "Black",
        "White",
        "Red",
        "Lime",
        "Blue",
        "Yellow",
        "Cyan",
        "Magenta",
        "Silver",
        "Gray",
        "Green",
        "Purple",
        "Navy"
    ],
    "rgbs": [
        (0, 0, 0),
        (255, 255, 255),
        (255, 0, 0),
        (0, 255, 0),
        (0, 0, 255),
        (255, 255, 0),
        (0, 255, 255),
        (255, 0, 255),
        (192, 192, 192),
        (128, 128, 128),
        (0, 128, 0),
        (128, 0, 128),
        (0, 0, 128)
    ]
}

# Colors for the active and inactive buttons of the dropdown list
COLOR_INACTIVE = (0, 255, 255)
COLOR_ACTIVE = (0, 0, 255)
COLOR_LIST_INACTIVE = (255, 0, 0)
COLOR_LIST_ACTIVE = (255, 255, 0)


# Creating a surface with text
def create_surf_with_text(text, font_size, text_rgb, bg_rgb):
    font = pygame.freetype.SysFont("Verdana", font_size, bold=True)
    surface, _ = font.render(text=text, fgcolor=text_rgb, bgcolor=bg_rgb)
    return surface.convert_alpha()


# Creating a dropdown list
class DropDown():
    def __init__(self, color_menu, color_opt, x, y, w, h, font, main, options):
        self.color_menu = color_menu
        self.color_option = color_opt
        self.rect = pygame.Rect(x, y, w, h)
        self.font = font
        self.main = main
        self.options = options
        self.draw_menu = False
        self.menu_active = False
        self.active_option = -1

    # Drawing the dropdown list
    def draw(self, surf):
        pygame.draw.rect(surf, self.color_menu[self.menu_active], self.rect, 0)
        msg = self.font.render(self.main, 1, (0, 0, 0))
        surf.blit(msg, msg.get_rect(center=self.rect.center))

        if self.draw_menu:
            for i, text in enumerate(self.options):
                rect = self.rect.copy()
                rect.y += (i + 1) * self.rect.height
                if i == self.active_option:
                    pygame.draw.rect(surf, self.color_option[1], rect, 0)
                else:
                    pygame.draw.rect(surf, self.color_option[0], rect, 0)
                msg = self.font.render(text, 1, (0, 0, 0))
                surf.blit(msg, msg.get_rect(center=rect.center))

    # Updating the dropdown list
    def update(self, event_list):
        mpos = pygame.mouse.get_pos()
        self.menu_active = self.rect.collidepoint(mpos)

        self.active_option = -1
        for i in range(len(self.options)):
            rect = self.rect.copy()
            rect.y += (i + 1) * self.rect.height
            if rect.collidepoint(mpos):
                self.active_option = i
                break

        if not self.menu_active and self.active_option == -1:
            self.draw_menu = False

        for event in event_list:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.menu_active:
                    self.draw_menu = not self.draw_menu
                elif self.draw_menu and self.active_option >= 0:
                    self.draw_menu = False
                    return self.active_option
        return -1


# Creatin a text
class TitleText(Sprite):
    def __init__(self, center, text, font_size, bg_rgb, txt_rgb):
        super().__init__()
        tlt_img = create_surf_with_text(text, font_size, txt_rgb, bg_rgb)
        self.image = tlt_img
        self.rect = tlt_img.get_rect(center=center)

    def draw(self, surface):
        surface.blit(self.image, self.rect)


# Creating an UI element like a button
class UIElement(Sprite):
    def __init__(self, center, text, font_size, bg_rgb, txt_rgb, action=None):

        super().__init__()
        self.mouse_over = False
        default_image = create_surf_with_text(text, font_size, txt_rgb, bg_rgb)
        hg_imag = create_surf_with_text(text, font_size * 1.2, txt_rgb, bg_rgb)
        self.images = [default_image, hg_imag]
        df_img = default_image.get_rect(center=center)
        hg_img = hg_imag.get_rect(center=center)
        self.rects = [df_img, hg_img]
        self.action = action

    @property
    def image(self):
        return self.images[1] if self.mouse_over else self.images[0]

    @property
    def rect(self):
        return self.rects[1] if self.mouse_over else self.rects[0]

    def update(self, mouse_pos, mouse_up):
        if self.rect.collidepoint(mouse_pos):
            self.mouse_over = True
            if mouse_up:
                return self.action
        else:
            self.mouse_over = False

    def draw(self, surface):
        surface.blit(self.image, self.rect)


# Defining different game states
class GameState(Enum):
    QUIT = -1
    TITLE = 0
    NEWGAME = 1
    NEW_LEVEL = 2
    OPTIONS = 3
    HIGH_SCORE = 4
    CREDITS = 5


# Main commands
def main():
    pygame.init()

    screen = pygame.display.set_mode((900, 700))
    game_state = GameState.TITLE
    while True:
        if game_state == GameState.TITLE:
            game_state = title_screen(screen)

        if game_state == GameState.NEWGAME:
            game_state = play_snake()

        if game_state == GameState.OPTIONS:
            game_state = options_menu(screen)

        if game_state == GameState.HIGH_SCORE:
            game_state = high_score(screen)

        if game_state == GameState.CREDITS:
            game_state = credits(screen)

        if game_state == GameState.QUIT:
            pygame.quit()
            return


# Creating the title screen
def title_screen(screen):
    text = TitleText((450, 200), "SNAKE", 150, B, W)
    start = UIElement((450, 300), "NEW GAME", 40, B, W, GameState.NEWGAME)
    options = UIElement((450, 350), "OPTIONS", 40, B, W, GameState.OPTIONS)
    scr = UIElement((450, 400), "HIGH SCORE", 40,  B, W, GameState.HIGH_SCORE)
    credits = UIElement((450, 450),  "CREDITS", 40,  B, W, GameState.CREDITS)
    quit = UIElement((450, 550), "EXIT", 40,  B, W, GameState.QUIT)

    buttons = RenderUpdates(start, options, scr, credits, quit)
    texts = RenderUpdates(text)

    return game_loop(screen, buttons, texts)


# Playing snake
def play_snake():
    pygame.quit()
    snake_game.run_game()
    exit()


# Creating the options menu
def options_menu(screen):
    txt = "Return to main menu"
    r_b = UIElement((150, 650), txt, 20, B, W, GameState.TITLE)
    clr = [COLOR_INACTIVE, COLOR_ACTIVE]
    clr_list = [COLOR_LIST_INACTIVE, COLOR_LIST_ACTIVE]
    fnt = pygame.font.SysFont(None, 30)
    txt = "Select Color"
    clr_d = COLOR_DICT["color"]
    option_d_p = DropDown(clr, clr_list, 350, 0, 200, 45, fnt, txt, clr_d)
    buttons = RenderUpdates(r_b)
    texts = RenderUpdates()

    while True:
        mouse_up = False
        event_list = pygame.event.get()
        for event in event_list:
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                mouse_up = True

        screen.fill(B)

        for button in buttons:
            ui_act = button.update(pygame.mouse.get_pos(), mouse_up)
            if ui_act is not None:
                return ui_act

        selected_option = option_d_p.update(event_list)
        if selected_option >= 0:
            with open("games_data/snake_color.txt", mode="w") as data:
                data.write(str(COLOR_DICT["color"][selected_option].lower()))
            option_d_p.main = option_d_p.options[selected_option]

        screen.fill(B)
        texts.draw(screen)
        buttons.draw(screen)
        option_d_p.draw(screen)
        pygame.display.flip()


# Creating the high score menu
def high_score(screen):
    txt = "Return to main menu"
    r_b = UIElement((150, 650), txt, 20, B, W, GameState.TITLE)
    with open("highscore/snake_high_score.txt", mode="r") as data:
        score = data.read()
    hg = f"Your current highscore is: {score}"
    score_text = TitleText((450, 350), hg, 45, B, W)

    buttons = RenderUpdates(r_b)
    texts = RenderUpdates(score_text)

    return game_loop(screen, buttons, texts)


# Creating the credits menu
def credits(screen):
    txt = "Return to main menu"
    r_b = UIElement((150, 650), txt, 20, B, W, GameState.TITLE)
    msg = TitleText((450, 350), "SNAKE 2021", 70, B, W)
    buttons = RenderUpdates(r_b)
    texts = RenderUpdates(msg)

    return game_loop(screen, buttons, texts)


# Creating the game loop
def game_loop(screen, buttons, texts):
    while True:
        mouse_up = False
        event_list = pygame.event.get()
        for event in event_list:
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                mouse_up = True

        screen.fill(B)

        for button in buttons:
            ui_act = button.update(pygame.mouse.get_pos(), mouse_up)
            if ui_act is not None:
                return ui_act

        texts.draw(screen)
        buttons.draw(screen)
        pygame.display.flip()


if __name__ == "__main__":
    main()
