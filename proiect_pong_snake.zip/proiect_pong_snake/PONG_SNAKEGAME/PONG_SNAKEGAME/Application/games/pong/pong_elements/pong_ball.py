import turtle

DX = -0.20
DY = 0.20
SPEED = 1.5


class Ball(turtle.Turtle):
    def __init__(self):
        turtle.Turtle.__init__(self)
        self.dy = DY
        self.dx = DX
        self.penup()
        self.shape("circle")
        self.color("white")
        self.speed = SPEED
