import turtle
from games.pong import pong_game
from game_interfaces import pong_interface
from game_interfaces import snake_interface
CENTER = (0, 0)
DX = 0.20
DY = -0.20
FONT = 18


class GameElements(turtle.Turtle):
    def __init__(self, scoreboard, ball, paddle_1, paddle_2, game_screen):
        turtle.Turtle.__init__(self)
        self.scrb = scoreboard
        self.ball = ball
        self.paddle_1 = paddle_1
        self.paddle_2 = paddle_2
        self.game_screen = game_screen
        self.running = True

    def reset(self):
        self.scrb.clear()
        self.ball.goto(CENTER)
        self.ball.dx = DX
        self.ball.dy = DY
        clr_pad_1 = pong_game.color_paddle_1.title()
        clr_pad_2 = pong_game.color_paddle_2.title()
        scr_a = pong_game.score_player_a
        scr_b = pong_game.score_player_b
        home = f"Home ({clr_pad_1}): {scr_a}"
        away = f"Away ({clr_pad_2}): {scr_b}"
        font = ("Verdana", FONT, "normal")
        if pong_game.response == 'horizontal':
            self.scrb.write(home + " " + away, align="center", font=font)
        elif pong_game.response == 'vertical':
            self.scrb.write(home + "\n" + away, align="center", font=font)

    def return_to_main(self):

        SCREEN_WIDTH = 800
        SCREEN_HEIGHT = 600
        self.game_screen.clear()
        self.running = False
        game_window = turtle.Screen()
        game_window.setup(SCREEN_WIDTH, SCREEN_HEIGHT)
        game_window.title("PlayTime")
        game_window.bgcolor("black")

        # Import main image
        game_window.bgpic("gifs/hello.gif")
        # Update the screen
        game_window.update()

        # Keyboard Binding
        game_window.listen()
        game_window.onkeypress(pong_interface.main, "p")
        game_window.onkeypress(snake_interface.main, "s")
