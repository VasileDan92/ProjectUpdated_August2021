import turtle


class ScoreBoard(turtle.Turtle):
    def __init__(self):
        turtle.Turtle.__init__(self)
        self.speed()
        self.color("yellow")
        self.penup()
        self.hideturtle()
