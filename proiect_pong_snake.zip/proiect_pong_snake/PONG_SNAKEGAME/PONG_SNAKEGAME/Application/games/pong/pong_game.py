# Creating a Paddle Pong Game in Python

# Create Graphics using turtle
# from snake_game import run_game
import turtle
from games.pong.pong_elements import pong_game_elements
from games.pong.pong_elements import pong_paddle
from games.pong.pong_elements import pong_ball
from games.pong.pong_elements import pong_scoreboard
# from pong_interface import lenght

# Constants
X_POS_PAD1_H = -350
X_POS_PAD2_H = 350
Y_POS_PAD1_H = 0
Y_POS_PAD2_H = 0

X_POS_PAD1_V = 0
X_POS_PAD2_V = 0
Y_POS_PAD1_V = 260
Y_POS_PAD2_V = -260
CENTER = (0, 0)

SCORE_POS_H_INITIAL = (0, 230)
SCORE_POS_H_FINAL = (0, 260)

SCORE_POS_V_INITIAL = (-160, 20)
SCORE_POS_V_FINAL = (-270, 0)

ZERO = 0
INVERT = -1

YCOR_H = (290, -290)
XCOR_H = (390, -390)

FONT = 18
SCORE_ADD = 1
MAXSCORE = 2

MAX_BALL_COR_H = (330, 340)

COLISSION_DIST = 50

YCOR_V = (-290, 290)
XCOR_V = (-350, 350)

GAME_FINAL_SCOREBOARD_V = (-250, 70)

MAX_BALL_COR_V = (240, 250)

FNT = ("Verdana", FONT, "normal")

switch_1 = False
switch_2 = False


# The game mode
response = ''

# Creating Score
score_player_a = ZERO
score_player_b = ZERO

# Colors of the paddles
color_paddle_1 = ''
color_paddle_2 = ''

# diagrama de clase pentru proiect - UML
# actualizare documentatie cu diagram de clase +
# customizare joc de pong +
# repository de pe git.

# Ball comes back to center after a goal in both game modes


def back_to_center(scoreboard, ball, paddle_1, paddle_2):
    global response
    ball.goto(CENTER)
    scoreboard.clear()
    if response == 'horizontal':
        ball.dx *= INVERT
        paddle_1.goto(X_POS_PAD1_H, Y_POS_PAD1_H)
        paddle_2.goto(X_POS_PAD2_H, Y_POS_PAD2_H)
    elif response == 'vertical':
        ball.dy *= INVERT
        paddle_1.goto(X_POS_PAD1_V, Y_POS_PAD1_V)
        paddle_2.goto(X_POS_PAD2_V, Y_POS_PAD2_V)

# The game was finished


def game_over(scoreboard, ball, paddle_1, paddle_2, game_screen, game_element):
    global response
    ball.goto(CENTER)
    ball.dx = ZERO
    ball.dy = ZERO

    message = "Wanna play again? Y for Yes, N for No!"
    if response == 'horizontal':
        scoreboard.goto(SCORE_POS_H_INITIAL)
        scoreboard.write(message, align="center", font=FNT)
        scoreboard.goto(SCORE_POS_H_FINAL)
    elif response == 'vertical':
        scoreboard.goto(SCORE_POS_V_INITIAL)
        scoreboard.write(message, align="center", font=FNT)
        scoreboard.goto(SCORE_POS_V_FINAL)

    scoreboard.color("yellow")
    # Choose to continue or finish the game
    game_screen.onkeypress(game_element.reset, "y")
    game_screen.onkeypress(game_element.return_to_main, "n")

    # if response == 'horizontal':
    #     paddle_1.goto(-350, 0)
    #     paddle_2.goto(+350, 0)
    # elif response == 'vertical':
    #     paddle_1.goto(0, +260)
    #     paddle_2.goto(0, -260)

# Reset the scoreboard after the games has finished


def reset_scoreboard(scoreboard):
    scoreboard.clear()
    scoreboard.goto(SCORE_POS_H_FINAL)

# Start Game


def start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element):
    global response
    global score_player_a
    global score_player_b
    global color_paddle_1
    global color_paddle_2
    with open("games_data/paddles_length.txt", mode= "r") as data:
        colision_dist = int(data.read()) * 10
    # Move the ball which starts from 0.
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Border Checking - Top and Down Border - Compare Coordinate.
    #  When it hits a certain point, it needs to bound
    if response == 'horizontal':
        if ball.ycor() > YCOR_H[0]:
            ball.sety(YCOR_H[0])
            # Reversing the direction
            ball.dy *= INVERT

        if ball.ycor() < YCOR_H[1]:
            ball.sety(YCOR_H[1])
            # Reversing the direction
            ball.dy *= INVERT

        # customizare joc, rotire la 90 grade. puterea OOP
        # - prin customizare. arhitectura + elementele jocului.

        # Border Checking - Left and Right
        if ball.xcor() > XCOR_H[0]:
            # Coming back to center
            back_to_center(scrb, ball, paddle1, paddle2)
            score_player_a += SCORE_ADD
            home = f"Home ({color_paddle_1.title()}): {score_player_a}"
            away = f"Away ({color_paddle_2.title()}): {score_player_b}"
            scrb.write(home + " " + away, align="center", font=FNT)
            if score_player_a == MAXSCORE:
                reset_scoreboard(scrb)
                scrb.color(color_paddle_1)
                scrb.write("Game Over! Home won", align="center", font=FNT)
                game_over(scrb, ball, paddle1, paddle2, g_screen, g_element)
                score_player_a = ZERO
                score_player_b = ZERO

        if ball.xcor() < XCOR_H[1]:
            # Coming back to center
            back_to_center(scrb, ball, paddle1, paddle2)
            score_player_b += SCORE_ADD
            scrb.clear()
            home = f"Home ({color_paddle_1.title()}): {score_player_a}"
            away = f"Away ({color_paddle_2.title()}): {score_player_b}"
            scrb.write(home + " " + away, align="center", font=FNT)
            if score_player_b == MAXSCORE:
                reset_scoreboard(scrb)
                scrb.color(color_paddle_2)
                message = "Game Over! Away won"
                scrb.write(message, align="center", font=FNT)
                game_over(scrb, ball, paddle1, paddle2, g_screen, g_element)
                score_player_a = ZERO
                score_player_b = ZERO
        
        # Paddle and Ball Collisions - avoid ball going after the paddle
        if -MAX_BALL_COR_H[0] > ball.xcor() > -MAX_BALL_COR_H[1]:
            pad1y = paddle1.ycor()
            if pad1y + colision_dist > ball.ycor() > pad1y - colision_dist:
                ball.setx(-MAX_BALL_COR_H[0])
                ball.dx *= INVERT

        if MAX_BALL_COR_H[0] < ball.xcor() < MAX_BALL_COR_H[1]:
            pad2y = paddle2.ycor()
            if pad2y + colision_dist > ball.ycor() > pad2y - colision_dist:
                ball.setx(MAX_BALL_COR_H[0])
                ball.dx *= INVERT
    elif response == 'vertical':
        # Border Checking - Left and Right Border -
        # Compare Coordinate. When it hits a certain point, it needs to bound
        if ball.xcor() > XCOR_V[1]:
            ball.setx(XCOR_V[1])
            # Reversing the direction
            ball.dx *= INVERT

        if ball.xcor() < XCOR_V[0]:
            ball.setx(XCOR_V[0])
            # Reversing the direction
            ball.dx *= INVERT

        # customizare joc, rotire la 90 grade. puterea OOP
        # - prin customizare. arhitectura + elementele jocului.

        # Border Checking - Up and Down
        if ball.ycor() < YCOR_V[0]:
            # Coming back to center
            back_to_center(scrb, ball, paddle1, paddle2)
            score_player_a += SCORE_ADD
            home = f"Home ({color_paddle_1.title()}): {score_player_a}"
            away = f"Away ({color_paddle_2.title()}): {score_player_b}"
            scrb.write(home + "\n" + away, align="center", font=FNT)
            if score_player_a == MAXSCORE:
                reset_scoreboard(scrb)
                scrb.color(color_paddle_1)
                scrb.goto(GAME_FINAL_SCOREBOARD_V)
                message = "Game Over! Home won"
                scrb.write(message, align="center", font=FNT)
                game_over(scrb, ball, paddle1, paddle2, g_screen, g_element)
                score_player_a = ZERO
                score_player_b = ZERO

        if ball.ycor() > YCOR_V[1]:
            # Coming back to center
            back_to_center(scrb, ball, paddle1, paddle2)
            score_player_b += SCORE_ADD
            scrb.clear()
            home = f"Home ({color_paddle_1.title()}): {score_player_a}"
            away = f"Away ({color_paddle_2.title()}): {score_player_b}"
            scrb.write(home + "\n" + away, align="center", font=FNT)
            if score_player_b == MAXSCORE:
                reset_scoreboard(scrb)
                scrb.color(color_paddle_2)
                scrb.goto(GAME_FINAL_SCOREBOARD_V)
                message = "Game Over! Away won"
                scrb.write(message, align="center", font=FNT)
                game_over(scrb, ball, paddle1, paddle2, g_screen, g_element)
                score_player_a = ZERO
                score_player_b = ZERO

        # Paddle and Ball Collisions - avoid ball going after the paddle

        if -MAX_BALL_COR_V[0] > ball.ycor() > -MAX_BALL_COR_V[1]:
            pad2x = paddle2.xcor()
            if pad2x - colision_dist < ball.xcor() < pad2x + colision_dist:
                ball.sety(-MAX_BALL_COR_V[0])
                ball.dy *= INVERT

        if MAX_BALL_COR_V[0] < ball.ycor() < MAX_BALL_COR_V[1]:
            pad1x = paddle1.xcor()
            if pad1x - colision_dist < ball.xcor() < pad1x + colision_dist:
                ball.sety(MAX_BALL_COR_V[0])
                ball.dy *= INVERT


def mode_choose():
    global response
    global switch_1
    # Creating Game Screen
    switch_1 = False
    game_screen = turtle.Screen()
    game_screen.bgpic("gifs/black.gif")
    game_screen.update()
    game_screen.title("Welcome to Pong Game")
    game_screen.bgcolor("black")
    game_screen.setup(width=800, height=600)
    titl = "Game Mode"
    prmt = "Choose the game mode: Horizontal or Vertical"
    # response = game_screen.textinput(titl, prmt)
    game_screen.listen()
    if response.lower() == 'horizontal' or response.lower() == 'vertical':
        if switch_1 is False:
            switch_1 = True
            run_game()


# Run the Game after P was pressed on the main menu and
#  the game mode was selected or the game was restarted
def run_game():
    global response
    global switch_2

    # Creating Game Screen
    game_screen = turtle.Screen()
    game_screen.bgpic("gifs/black.gif")
    game_screen.update()
    game_screen.title("Welcome to Pong Game")
    game_screen.bgcolor("black")
    game_screen.setup(width=800, height=600)
    # Stop window from updating
    # Game speed is increased
    game_screen.tracer(0)

    # Paddle 1
    paddle_1 = pong_paddle.Paddle()
    # Set shape and color of Paddle 1
    paddle_1.shape("square")
    global color_paddle_1
    with open("games_data/paddle1_color.txt", mode="r") as data:
        color_paddle_1 = data.read()
    # title_pad1 = "Paddle 1"
    # prompt_pad1 = "Type the color of the first paddle:"
    # color_paddle_1 = game_screen.textinput(title_pad1, prompt_pad1)
    paddle_1.color(color_paddle_1)
    # Set position of the Paddle 1
    if response == 'horizontal':
        with open("games_data/paddles_length.txt", mode= "r") as data:
            lenght = int(data.read())
        paddle_1.shapesize(stretch_wid=lenght, stretch_len=1)
        paddle_1.goto(X_POS_PAD1_H, Y_POS_PAD1_H)
    elif response == 'vertical':
        # The paddle needs to pe reshaped for the second game mode
        with open("games_data/paddles_length.txt", mode= "r") as data:
            lenght = int(data.read())
        paddle_1.shapesize(stretch_wid=1, stretch_len=lenght)
        paddle_1.goto(X_POS_PAD1_V, Y_POS_PAD1_V)

    # Paddle 2
    paddle_2 = pong_paddle.Paddle()
    # Set shape and color of Paddle 2
    paddle_2.shape("square")
    global color_paddle_2
    with open("games_data/paddle2_color.txt", mode="r") as data:
        color_paddle_2 = data.read()
    # title_pad2 = "Paddle 2"
    # prompt_pad2 = "Type the color of the second paddle:"
    # color_paddle_2 = game_screen.textinput(title_pad2, prompt_pad2)
    paddle_2.color(color_paddle_2)
    # Set position of the Paddle 2
    if response == 'horizontal':
        with open("games_data/paddles_length.txt", mode= "r") as data:
            lenght = int(data.read())
        paddle_2.shapesize(stretch_wid=lenght, stretch_len=1)
        paddle_2.goto(X_POS_PAD2_H, Y_POS_PAD2_H)
    elif response == 'vertical':
        with open("games_data/paddles_length.txt", mode= "r") as data:
            lenght = int(data.read())
        paddle_2.shapesize(stretch_wid=1, stretch_len=lenght)
        paddle_2.goto(X_POS_PAD2_V, Y_POS_PAD2_V)

    # Ball
    ball = pong_ball.Ball()
    # Set shape and color of ball
    ball.shape("circle")
    ball.color("white")
    # Set position on the middle
    ball.goto(CENTER)

    # Scoreboard
    scoreboard = pong_scoreboard.ScoreBoard()
    if response == 'horizontal':
        scoreboard.goto(SCORE_POS_H_FINAL)
        home = f"Home ({color_paddle_1.title()}): {score_player_a}"
        away = f"Away ({color_paddle_2.title()}): {score_player_b}"
        scoreboard.write(home + " " + away, align="center", font=FNT)
    elif response == 'vertical':
        scoreboard.goto(SCORE_POS_V_FINAL)
        home = f"Home ({color_paddle_1.title()}): {score_player_a}"
        away = f"Away ({color_paddle_2.title()}): {score_player_b}"
        scoreboard.write(home + "\n" + away, align="center", font=FNT)

    # Generate Game Elements
    scrb = scoreboard
    padd1 = paddle_1
    padd2 = paddle_2
    g_scr = game_screen
    g_elem = pong_game_elements.GameElements(scrb, ball, padd1, padd2, g_scr)
    g_elem.running = True
    while g_elem.running:
        # Keyboard binding
        game_screen.listen()
        if response == 'horizontal':
            # Paddle 1 Moving up and down
            game_screen.onkeypress(paddle_1.paddle_moving_up, "w")
            game_screen.onkeypress(paddle_1.paddle_moving_down, "s")
            # Paddle 2 Moving up and down
            game_screen.onkeypress(paddle_2.paddle_moving_up, "i")
            game_screen.onkeypress(paddle_2.paddle_moving_down, "k")
        elif response == 'vertical':
            # Paddle 1 Moving left and right
            game_screen.onkeypress(paddle_1.paddle_moving_left, "w")
            game_screen.onkeypress(paddle_1.paddle_moving_right, "s")
            # Paddle 2 Moving left and right
            game_screen.onkeypress(paddle_2.paddle_moving_left, "i")
            game_screen.onkeypress(paddle_2.paddle_moving_right, "k")

        # Start game
        start_pong_game(scrb, ball, padd1, padd2, g_scr, g_elem)
        # Update screen
        game_screen.update()
