import turtle

POSITION = (0, 250)


class ScoreBoard(turtle.Turtle):
    def __init__(self):
        turtle.Turtle.__init__(self)
        self.speed()
        self.shape("square")
        self.color("white")
        self.penup()
        self.hideturtle()
        self.goto(POSITION)
