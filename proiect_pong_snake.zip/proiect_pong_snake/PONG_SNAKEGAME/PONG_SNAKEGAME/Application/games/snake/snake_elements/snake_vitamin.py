import turtle

POSITION = (0, 150)
COLOR = "red"
SHAPE_SZ = 0.5


class SnakeVitamin(turtle.Turtle):
    def __init__(self):
        turtle.Turtle.__init__(self)
        self.speed(0)
        self.shape("circle")
        self.shapesize(SHAPE_SZ, SHAPE_SZ)
        self.color(COLOR)
        self.penup()
        self.goto(POSITION)
