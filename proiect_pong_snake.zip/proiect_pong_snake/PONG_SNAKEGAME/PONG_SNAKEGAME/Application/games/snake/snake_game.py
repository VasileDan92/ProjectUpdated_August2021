import turtle
import time
from games.snake.snake_elements import snake_head
from games.snake.snake_elements import snake_vitamin
import random
from games.snake.snake_elements import snake_scoreboard
from games.snake.snake_elements import snake_game_elements

# Constants

CENTER = (0, 0)
VITAMIN_POS = (0, 150)
SCORE_POS_INITIAL = (0, 230)
SCORE_POS_FINAL = (0, 260)
BORDER_X = (-350, 350)
BORDER_Y = (-170, 170)
SEGEMTS_GO_POS = (1000, 1000)
ZERO = 0
DELAY = 0.1
FONT = 16
COLLISION_DIST = 20
SCORE_COST = 10
DELAY_SHORT = -0.001
FNT = ("Verdana", 16, "normal")

# Color of the snake()
snake_color = ''
# Delay of 0.1 seconds
delay = 0.1
# Score and highscore.
# The highscore is initialized everytime
# with the value saved in the snake_high_score.txt file
score = 0

with open("games_data/snake_color.txt", mode="r") as data:
    snake_color = data.read()

with open("highscore/snake_high_score.txt", mode="r") as data:
    high_score = int(data.read())

# List with body parts of snake: start of the game - 0 vitamins, so []
segments = []


def game_over(scoreboard, head, vitamin, game_screen, game_element):
    global high_score
    # When the game is over the highscore is overwritten
    # in the snake_high_score.txt file
    with open("highscore/snake_high_score.txt", mode="w") as data:
        data.write(str(high_score))
    head.goto(CENTER)
    vitamin.goto(VITAMIN_POS)
    scoreboard.goto(SCORE_POS_INITIAL)
    message = "Wanna play again? Y for Yes, N for No!"
    scoreboard.write(message, align="center", font=FNT)
    scoreboard.goto(SCORE_POS_FINAL)

    game_screen.onkeypress(game_element.reset, "y")
    game_screen.onkeypress(game_element.return_to_main, "n")


def reset_scoreboard(scoreboard):
    scoreboard.clear()
    scoreboard.goto(SCORE_POS_FINAL)


# Starting Game
def start_snake_game(scoreboard, head, vitamin, game_screen, game_element):
    game_screen.update()
    global score
    global high_score
    global delay

    # Check for a collision with the border
    hd_x = head.xcor()
    hd_y = head.ycor()
    br_x1 = BORDER_X[1]
    br_x0 = BORDER_X[0]
    br_y1 = BORDER_Y[1]
    br_y0 = BORDER_Y[0]
    if hd_x > br_x1 or hd_x < br_x0 or hd_y > br_y1 or hd_y < br_y0:
        time.sleep(1)
        head.goto(CENTER)
        head.direction = "stop"

        # Hide the segments
        for segment in segments:
            segment.goto(SEGEMTS_GO_POS)

        # Clear the segments list
        segments.clear()

        # Reset the score
        score = ZERO

        # Reset the delay
        delay = DELAY

        scoreboard.clear()
        message = f"Score: {score}  High Score: {high_score}"
        scoreboard.write(message, align="center", font=FNT)
        game_over(scoreboard, head, vitamin, game_screen, game_element)

        # Check for a collision with the food
    if head.distance(vitamin) < COLLISION_DIST:
        # Snake color
        global snake_color

        # Move the food to a random spot
        x = random.randint(BORDER_X[0], BORDER_Y[1])
        y = random.randint(BORDER_Y[0], BORDER_Y[1])
        vitamin.goto(x, y)

        # Add a segment
        new_segment = turtle.Turtle()
        new_segment.speed(0)
        new_segment.shape("square")
        new_segment.color(snake_color)
        new_segment.penup()
        segments.append(new_segment)

        # Shorten the delay
        delay -= DELAY_SHORT

        # Increase the score
        score += SCORE_COST

        if score > high_score:
            high_score = score

        scoreboard.clear()
        message = f"Score: {score}  High Score: {high_score}"
        scoreboard.write(message, align="center", font=FNT)

        # Move the end segments first in reverse order
    for index in range(len(segments) - 1, ZERO, -1):
        x = segments[index - 1].xcor()
        y = segments[index - 1].ycor()
        segments[index].goto(x, y)

    # Move segment 0 to where the head is
    if len(segments) > ZERO:
        x = head.xcor()
        y = head.ycor()
        segments[0].goto(x, y)

    head.move()

    # Check for head collision with the body segments
    for segment in segments:
        if segment.distance(head) < COLLISION_DIST:
            time.sleep(1)
            head.goto(CENTER)
            head.direction = "stop"

            # Hide the segments
            for segment in segments:
                segment.goto(SEGEMTS_GO_POS)

            # Clear the segments list
            segments.clear()

            # Reset the score
            score = ZERO

            # Reset the delay
            delay = DELAY

            # Update the score display
            scoreboard.clear()
            message = f"Score: {score}  High Score: {high_score}"
            scoreboard.write(message, align="center", font=FNT)

            game_over(scoreboard, head, vitamin, game_screen, game_element)

    time.sleep(delay)


def run_game():
    # Creating Game Screen
    game_screen = turtle.Screen()
    game_screen.bgpic("gifs/border.gif")
    game_screen.update()
    game_screen.title("Welcome to Snake Game")
    game_screen.bgcolor("black")
    game_screen.setup(width=800, height=600)
    # turns off animation on the screen
    game_screen.tracer(0)

    # Choose color of the snake
    global snake_color
    # snk_title = "Snake Color"
    # snk_prompt = "Choose the color of the snake: "
    # snake_color = game_screen.textinput(snk_title, snk_prompt)

    # Define objects
    with open("games_data/snake_color.txt", mode="r") as data:
            snake_color = data.read()
    head = snake_head.SnakeHead()
    vitamin = snake_vitamin.SnakeVitamin()

    # ScoreBoard
    scoreboard = snake_scoreboard.ScoreBoard()
    scoreboard.goto(SCORE_POS_FINAL)
    message = f"Score: 0 High Score: {high_score}"
    scoreboard.write(message, align="center", font=FNT)

    # Generate Game Elements
    scrb = scoreboard
    vit = vitamin
    g_scr = game_screen
    g_element = snake_game_elements.GameElements(scrb, head, vit, g_scr)
    g_element.running = True
    while g_element.running:
        # Keyboard binding
        game_screen.listen()
        game_screen.onkeypress(head.go_up, "w")
        game_screen.onkeypress(head.go_down, "s")
        game_screen.onkeypress(head.go_left, "a")
        game_screen.onkeypress(head.go_right, "d")
        # Start game
        start_snake_game(scoreboard, head, vitamin, game_screen, g_element)
        # Update screen
        game_screen.update()
    game_screen.mainloop()
