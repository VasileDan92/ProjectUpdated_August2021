# Main Menu for Games
import turtle

from game_interfaces import snake_interface
from game_interfaces import pong_interface
# Define values for width and height

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600


def game():
    while True:
        game_window = turtle.Screen()
        game_window.setup(SCREEN_WIDTH, SCREEN_HEIGHT)
        game_window.title("PlayTime")
        game_window.bgcolor("black")

        # Import main image
        game_window.bgpic("gifs/hello.gif")
        # Update the screen
        game_window.update()

        # Keyboard Bindings
        game_window.listen()
        game_window.onkeypress(pong_interface.main, "p")

        game_window.onkeypress(snake_interface.main, "s")


game()
