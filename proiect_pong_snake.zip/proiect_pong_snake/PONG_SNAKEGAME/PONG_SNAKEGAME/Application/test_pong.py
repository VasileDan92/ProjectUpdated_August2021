import unittest
from games.pong.pong_elements.pong_game_elements import GameElements
from games.pong.pong_elements import pong_paddle
from games.pong.pong_elements import pong_ball
from games.pong.pong_elements import pong_scoreboard
from games.pong.pong_game import start_pong_game, back_to_center
from games.pong.pong_game import mode_choose, game_over, reset_scoreboard
from games.pong.pong_game import run_game
from games.pong import pong_game
import turtle

CENTER = (0, 0)
PAD1_POS_H = (-350, 0)
PAD2_POS_H = (350, 0)
PAD1_POS_V = (0, 260)
PAD2_POS_V = (0, -260)
INVERT = -1
HEIGHT_W = 500
WIDTH_W = 700
ZERO = 0
SCOREBOARD_H_COOR = (0, 260)
SCOREBOARD_V_COOR = (-270, 0)
HEIGHT = 600
WIDTH = 800
BALL_1 = (0, 300)
BALL_2 = (400, 0)
SCORE = 1
BALL_3 = (-345, 300)
BALL_4 = (360, 0)
BALL_5 = (0, -280)
BALL_6 = (0, 292)
BALL_7 = (300, -265)
BALL_8 = (345, 265)

with open("test_reports/test_report_pong.txt", mode="a") as data:
    data.write("Pong Tests" + '\n' + '\n')

cnt = 0
nr_tst = 0

class TestPong(unittest.TestCase):
    def test_back_to_center(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("[RUN       ] Testing if every elements goes back to it's initial position")
        print("[       OK ] Testing if every elements goes back to it's initial position")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
            data.write("test_pong.test_back_to_center" + '\n')
        scoreboard = pong_scoreboard.ScoreBoard()
        ball = pong_ball.Ball()
        paddle_1 = pong_paddle.Paddle()
        paddle_2 = pong_paddle.Paddle()
        pong_game.response = 'horizontal'
        back_to_center(scoreboard, ball, paddle_1, paddle_2)
        try:
            self.assertIsNone(scoreboard.clear())
            self.assertEqual(ball.position(), CENTER)
            self.assertNotEqual(ball.dx, INVERT * ball.dx)
            self.assertEqual(paddle_1.position(), PAD1_POS_H)
            self.assertEqual(paddle_2.position(), PAD2_POS_H)
            pong_game.response = 'vertical'
            back_to_center(scoreboard, ball, paddle_1, paddle_2)
            self.assertNotEqual(ball.dy, INVERT * ball.dy)
            self.assertEqual(paddle_1.position(), PAD1_POS_V)
            self.assertEqual(paddle_2.position(), PAD2_POS_V)
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_back_to_center [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_back_to_center [FAILED]" + '\n' + '\n')

    def test_window(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Testing if the window is properly created")
        print("[     FAIL ] Testing if the window is properly created")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
            data.write("test_pong.test_window" + '\n')
        game_screen = turtle.Screen()
        game_screen.setup(width=WIDTH_W, height=HEIGHT_W)
        mode_choose()
        try:
            self.assertEqual(game_screen.bgcolor(), "black")
            self.assertEqual(game_screen.window_width(), WIDTH_W)
            self.assertEqual(game_screen.window_height(), HEIGHT_W)
            game_screen.clear()
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_window [PASSED]" + '\n' + '\n')
        except:
            cnt += 1
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_window [FAILED]" + '\n' + '\n')

    def test_game_over(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Testing if the game is over")
        print("[       OK ] Testing if the game is over")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
            data.write("test_pong.test_game_over" + '\n')
        scrb = pong_scoreboard.ScoreBoard()
        ball = pong_ball.Ball()
        paddle1 = pong_paddle.Paddle()
        paddle2 = pong_paddle.Paddle()
        g_screen = turtle.Screen()
        g_element = GameElements(scrb, ball, paddle1, paddle2, g_screen)
        pong_game.response = 'horizontal'
        game_over(scrb, ball, paddle1, paddle2, g_screen, g_element)
        try:
            self.assertEqual(ball.position(), CENTER)
            self.assertEqual(ball.dx, ZERO)
            self.assertEqual(ball.dy, ZERO)
            self.assertEqual(scrb.position(), SCOREBOARD_H_COOR)
            self.assertEqual(scrb.color(), ("yellow", "yellow"))
            pong_game.response = 'vertical'
            game_over(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(scrb.position(), SCOREBOARD_V_COOR)
            g_screen.clear()
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_game_over [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_game_over [FAILED]" + '\n' + '\n')

    def test_reset_scoreboard(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Testing if the scoreboard is reset")
        print("[       OK ] Testing if the scoreboard is reset")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
            data.write("test_pong.test_reset_scoreboard" + '\n')
        scoreboard = pong_scoreboard.ScoreBoard()
        scoreboard.write("This test verifies if the scoreboard is reset")
        reset_scoreboard(scoreboard)
        try:
            self.assertEqual(scoreboard.clear(), None)
            self.assertEqual(scoreboard.position(), SCOREBOARD_H_COOR)
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_reset_scoreboard [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_reset_scoreboard [FAILED]" + '\n' + '\n')

    def test_start_pong_game(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Testing if the game starts properly")
        print("[       OK ] Testing if the game starts properly")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
            data.write("test_pong.test_start_pong_game" + '\n')
        scrb = pong_scoreboard.ScoreBoard()
        ball = pong_ball.Ball()
        paddle1 = pong_paddle.Paddle()
        paddle2 = pong_paddle.Paddle()
        g_screen = turtle.Screen()
        g_element = GameElements(scrb, ball, paddle1, paddle2, g_screen)
        pong_game.response = 'horizontal'

        try:
            ball.goto(BALL_1[0], BALL_1[1])
            ball.dy = 1
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(ball.ycor(), BALL_1[1] - 10)
            self.assertEqual(ball.dy, INVERT)
            ball.home()

            ball.goto(BALL_1[0], -BALL_1[1])
            ball.dy = 1
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(ball.ycor(), -BALL_1[1] + 10)
            self.assertEqual(ball.dy, INVERT)
            ball.home()

            ball.goto(BALL_2[0], BALL_2[1])
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(pong_game.score_player_a, SCORE)
            self.assertEqual(pong_game.score_player_b, ZERO)
            ball.home()

            ball.goto(-BALL_2[0], BALL_2[1])
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(pong_game.score_player_b, SCORE)
            self.assertEqual(pong_game.score_player_a, SCORE)
            ball.home()

            paddle1.goto(BALL_1[0], BALL_1[1])
            ball.goto(BALL_3[0], BALL_3[1])
            ball.dx = 1
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(ball.position(), (BALL_3[0] + 5, BALL_3[1] - 10))
            self.assertEqual(ball.dx, INVERT)

            paddle2.goto(BALL_1[0], BALL_1[1])
            ball.goto(-BALL_3[0], BALL_3[1])
            ball.dx = 1
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(ball.position(), (-BALL_3[0] - 5, BALL_3[1] - 10))
            self.assertEqual(ball.dx, INVERT)

            pong_game.response = 'vertical'

            ball.goto(BALL_4[0], BALL_4[1])
            ball.dx = 1
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(ball.xcor(), BALL_4[0] - 10)
            self.assertEqual(ball.dy, INVERT)
            ball.home()

            ball.goto(-BALL_4[0] + 10, BALL_4[1])
            ball.dx = 1
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(ball.xcor(), -BALL_4[0] + 11)
            self.assertEqual(ball.dy, INVERT)
            ball.home()

            ball.goto(BALL_5[0], BALL_5[1])
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(pong_game.score_player_a, 1)
            self.assertEqual(pong_game.score_player_b, 1)
            ball.home()

            ball.goto(BALL_6[0], BALL_6[1])
            self.assertEqual(pong_game.score_player_b, 1)
            self.assertEqual(pong_game.score_player_a, 1)
            ball.home()

            paddle2.goto(BALL_1[1], BALL_1[0])
            ball.goto(BALL_7[0], BALL_7[1])
            ball.dy = 1
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(ball.position(), (BALL_7[0] + 1, BALL_7[1] + 5))
            self.assertEqual(ball.dy, INVERT)

            paddle1.goto(BALL_8[0], ZERO)
            ball.goto(BALL_8[0], BALL_8[1])
            ball.dy = 1
            start_pong_game(scrb, ball, paddle1, paddle2, g_screen, g_element)
            self.assertEqual(ball.position(), (BALL_8[0] + 1, BALL_8[1] - 5))
            self.assertEqual(ball.dy, INVERT)
            g_screen.clear()
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_start_pong_game [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_start_pong_game [FAILED]" + '\n' + '\n')

    def test_the_mode_chose(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Testing if game mode slection is working")
        print("[       OK ] Testing if game mode slection is working")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
            data.write("test_pong.test_the_mode_chose" + '\n')
        game_screen = turtle.Screen()
        mode_choose()
        try:
            self.assertEqual(game_screen.bgcolor(), "black")
            self.assertEqual(game_screen.window_width(), WIDTH)
            self.assertEqual(game_screen.window_height(), HEIGHT)
            self.assertEqual(pong_game.switch_1, True)
            game_screen.clear()
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_the_mode_chose [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_the_mode_chose [FAILED]" + '\n' + '\n')

    def test_run_game(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Testing if the game runs properly")
        print("[     FAIL ] Testing if the game runs properly")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
            data.write("test_pong.test_run_game" + '\n')
        game_screen = turtle.Screen()
        paddle_1 = pong_paddle.Paddle()
        paddle_2 = pong_paddle.Paddle()
        ball = pong_ball.Ball()
        run_game()
        try:
            self.assertEqual(game_screen.bgcolor(), "black")
            self.assertEqual(game_screen.window_width(), WIDTH)
            self.assertEqual(game_screen.window_height(), HEIGHT)
            self.assertEqual(paddle_1.shape(), "square")
            self.assertEqual(paddle_2.shape(), "square")
            self.assertEqual(ball.shape(), "circle")
            self.assertEqual(ball.color(), ("white", "white"))
            self.assertEqual(ball.position(), CENTER)
            game_screen.clear()
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_run_game [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_run_game [FAILED]" + '\n' + '\n')

    def test_shape(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Tesing if the initial shape remains the same")
        print("[     FAIL ] Tesing if the initial shape remains the same")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
            data.write("test_pong.test_shape" + '\n')
        paddle_1 = pong_paddle.Paddle()
        paddle_1.shape("circle")
        paddle_2 = pong_paddle.Paddle()
        paddle_2.shape("circle")
        ball = pong_ball.Ball()
        ball.shape("square")
        run_game()
        try:
            self.assertEqual(paddle_1.shape(), "square")
            self.assertEqual(paddle_2.shape(), "square")
            self.assertEqual(ball.shape(), "circle")
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_shape [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write("[RUN] test_pong.test_shape [FAILED]" + '\n' + '\n')


    def test_zfinal(self):
        if cnt >= 1:
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write(f"{nr_tst - cnt} tests 'from test_pong' PASSED" + '\n' + f"{cnt} tests from 'test_pong' - test_pong.test_shape, test_pong.test_start_pong_game, test_pong.test_window FAILED")
        else:
            with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write(f"{nr_tst - cnt} test 'from test_pong' PASSED")
        with open("test_reports/test_report_pong.txt", mode="a") as data:
                data.write('\n' + f"{nr_tst - cnt} / {cnt}")

if __name__ == '__main__':
    unittest.main()
    