import unittest
import turtle
from games.snake.snake_elements.snake_game_elements import snake_game
from games.snake.snake_elements.snake_game_elements import GameElements
from games.snake.snake_elements import snake_head
from games.snake.snake_elements import snake_vitamin
from games.snake.snake_elements import snake_scoreboard

HEIGHT_W = 500
WIDTH_W = 700
CENTER = (0, 0)
ZERO = 0
SCORE = 10
WIDTH = 800
HEIGHT = 600
VITAMIN = (0, 150)
SCOREBOARD = (0, 260)

with open("test_reports/test_report_snake.txt", mode="a") as data:
    data.write("Snake Tests" + '\n' + '\n')

cnt = 0
nr_tst = 0

class TestSnake(unittest.TestCase):
    def test_game_over(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("[RUN       ] Test if the game is over")
        print("[       OK ] Test if the game is over")
        with open("test_reports/test_report_snake.txt", mode="a") as data:
            data.write("test_snake.test_game_over" + '\n')
        head = snake_head.SnakeHead()
        vitamin = snake_vitamin.SnakeVitamin()
        scrb = snake_scoreboard.ScoreBoard()
        g_screen = turtle.Screen()
        g_window = turtle.Screen()
        g_element = GameElements(scrb, head, vitamin, g_screen)
        snake_game.game_over(scrb, head, vitamin, g_screen, g_element)
        try:
            self.assertEqual(head.position(), CENTER)
            self.assertEqual(vitamin.position(), VITAMIN)
            self.assertEqual(scrb.position(), SCOREBOARD)
            g_element.reset()
            self.assertEqual(head.position(), CENTER)
            self.assertEqual(vitamin.position(), VITAMIN)
            g_element.return_to_main()
            self.assertEqual(g_window.window_height(), HEIGHT)
            self.assertEqual(g_window.window_width(), WIDTH)
            self.assertEqual(g_window.bgcolor(), "black")
            self.assertEqual(g_window.bgpic(), "gifs/hello.gif")
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write("[RUN] test_snake.test_game_over [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write("[RUN] test_snake.test_game_over [FAILED]" + '\n' + '\n')


    def test_reset_scoreboard(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Test if the scoreboard is reset")
        print("[       OK ] Test if the scoreboard is reset")
        with open("test_reports/test_report_snake.txt", mode="a") as data:
            data.write("test_snake.test_reset_scoreboard" + '\n')
        scoreboard = snake_scoreboard.ScoreBoard()
        try:
            snake_game.reset_scoreboard(scoreboard)
            self.assertEqual(scoreboard.position(), SCOREBOARD)
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write("[RUN] test_snake.test_reset_scoreboard [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write("[RUN] test_snake.test_reset_scoreboard [FAILED]" + '\n' + '\n')


    def test_start_snake_game(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Test if the game starts properly")
        print("[       OK ] Test if the game starts properly")
        with open("test_reports/test_report_snake.txt", mode="a") as data:
            data.write("test_snake.test_start_snake_game" + '\n')
        head = snake_head.SnakeHead()
        vitamin = snake_vitamin.SnakeVitamin()
        scrb = snake_scoreboard.ScoreBoard()
        g_screen = turtle.Screen()
        g_element = GameElements(scrb, head, vitamin, g_screen)
        head.goto(360, 180)
        snake_game.score = SCORE
        snake_game.start_snake_game(scrb, head, vitamin, g_screen, g_element)
        try:
            self.assertEqual(snake_game.score, ZERO)
            self.assertEqual(head.position(), CENTER)
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write("[RUN] test_snake.test_start_snake_game [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write("[RUN] test_snake.test_start_snake_game [FAILED]" + '\n' + '\n')


    def test_window(self):
        global cnt
        global nr_tst
        nr_tst += 1
        print("\n[RUN       ] Testing if the window is properly created")
        print("[       OK ] Testing if the window is properly created")
        with open("test_reports/test_report_snake.txt", mode="a") as data:
            data.write("test_snake.test_window" + '\n')
        g_screen = turtle.Screen()
        head = snake_head.SnakeHead()
        vitamin = snake_vitamin.SnakeVitamin()
        scoreboard = snake_scoreboard.ScoreBoard()
        g_screen = turtle.Screen()
        g_screen.setup(width=WIDTH_W, height=HEIGHT_W)
        g_element = GameElements(scoreboard, head, vitamin, g_screen)
        g_element.return_to_main()
        try:
            self.assertEqual(g_screen.bgcolor(), "black")
            self.assertEqual(g_screen.window_width(), WIDTH_W)
            self.assertEqual(g_screen.window_height(), HEIGHT_W)
            g_screen.clear()
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write("[RUN] test_snake.test_window [PASSED]" + '\n' + '\n')
        except AssertionError:
            cnt += 1
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write("[RUN] test_snake.test_window [FAILED]" + '\n' + '\n')

    def test_zfinal(self):
        if cnt >= 1:
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write(f"{nr_tst - cnt} tests 'from test_snake' PASSED" + '\n' + f"{cnt} tests from 'test_snake' - test_snake.test_window FAILED" + '\n')
        else:
            with open("test_reports/test_report_snake.txt", mode="a") as data:
                data.write(f"{nr_tst - cnt} test 'from test_snake' PASSED" + '\n')
        with open("test_reports/test_report_snake.txt", mode="a") as data:
            data.write(f"{nr_tst - cnt} / {cnt}")

if __name__ == '__main__':
    unittest.main()
